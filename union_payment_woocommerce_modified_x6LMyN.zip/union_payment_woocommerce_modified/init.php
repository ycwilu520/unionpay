<?php

/*
Plugin Name: union_payment_woocommerce
Plugin URI: https://GitHub.com/ycwilu520
Description: 这是一个银联支付的插件，并且支持手动和自动退款，项目开源在github上，需要联系 ycwilu@outlook.com
Version: v1.01
Author: 老严支付
Author URI: https://GitHub.com/ycwilu520
License: MIT
*/

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

if (! defined ( 'LAOYAN_UNION_PAYMENT' )) {define ( 'LAOYAN_UNION_PAYMENT', 'LAOYAN_UNION_PAYMENT' );} else {return;}
define('LAOYAN_UNION_ONLINE_VERSION','1.0.0');
define('laoyan_union_payment_ID','wc_laoyan_union_payment_payment_gateway');
define('laoyan_union_payment_DIR',rtrim(plugin_dir_path(__FILE__),'/'));
define('laoyan_union_payment_URL',rtrim(plugin_dir_url(__FILE__),'/'));
load_plugin_textdomain( 'laoyan_union_payment', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/'  );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'laoyan_union_payment_payment_gateway_plugin_edit_link' );
add_action( 'init', 'laoyan_union_payment_payment_geteway_init' );

if(!function_exists('laoyan_union_payment_payment_geteway_init')){
    function laoyan_union_payment_payment_geteway_init() {
        if( !class_exists('WC_Payment_Gateway') )  return;
        require_once laoyan_union_payment_DIR .'/class-laoyan_union_payment_wc_payment_gateway.php';   
        $api = new WC_laoyan_union_payment_Payment_Gateway();
        
       // $api->check_wechatpay_response();
       // 添加银联支付
       add_filter('woocommerce_payment_gateways',array($api,'woocommerce_laoyan_union_payment_add_gateway' ),10,1);
       add_action( 'wp_ajax_laoyan_union_payment_PAYMENT_GET_ORDER', array($api, "get_order_status" ) );
       add_action( 'wp_ajax_nopriv_laoyan_union_payment_PAYMENT_GET_ORDER', array($api, "get_order_status") );
       // 支付页面
       add_action( 'woocommerce_receipt_'.$api->id, array($api, 'receipt_page'));
       // 保存设置
       add_action( 'woocommerce_update_options_payment_gateways_' . $api->id, array ($api,'process_admin_options') ); // WC >= 2.0
       add_action( 'woocommerce_update_options_payment_gateways', array ($api,'process_admin_options') );

       add_action( 'woocommerce_thankyou', array( $api, 'thankyou_page' ) );
       // add_action( 'woocommerce_receipt_alipay_wap', array( $api, 'receipt_page' ) );

       // Payment listener/API hook
       add_action( 'woocommerce_api_' . $api->id, array( $api, 'check_laoyan_union_payment_response' ) );

       // Display Alipay Trade No. in the backend.
       //add_action( 'woocommerce_admin_order_data_after_billing_address',array( $api, 'wc_laoyan_union_payment_display_order_meta_for_admin' ) );
       //add_action( 'wp_enqueue_scripts', array ($api,'wp_enqueue_scripts') );
    }
}

function laoyan_union_payment_payment_gateway_plugin_edit_link( $links ){
    return array_merge(
        array(
            'settings' => '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section='.laoyan_union_payment_ID) . '">'.__( 'Settings', 'laoyan_union_payment' ).'</a>'
        ),
        $links
    );
}

 /**
 * Display Trade No. in the backend.
 * 
 * @access public
 * @param mixed $order
 * @return void
 */
function wc_laoyan_union_payment_display_order_meta_for_admin( $order ){
    $trade_no = get_post_meta( $order->id, 'Online Trade No.', true );
    if( !empty($trade_no ) ){
        echo '<p><strong>' . __( 'Online Trade No.:', 'laoyan_union_payment') . '</strong><br />' .$trade_no. '</p>';
    }
}
?>